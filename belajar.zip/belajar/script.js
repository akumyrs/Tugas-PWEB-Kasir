function updatePrice(type) {
  const foodDropdown = document.getElementById("foodDropdown");
  const drinkDropdown = document.getElementById("drinkDropdown");
  const foodPrice = document.getElementById("foodPrice");
  const drinkPrice = document.getElementById("drinkPrice");

  if (type === "food") {
    const selectedFoodPrice = parseFloat(foodDropdown.value);
    foodPrice.textContent = `Harga: Rp ${selectedFoodPrice.toLocaleString(
      "id-ID"
    )}`;
  } else if (type === "drink") {
    const selectedDrinkPrice = parseFloat(drinkDropdown.value);
    drinkPrice.textContent = `Harga: Rp ${selectedDrinkPrice.toLocaleString(
      "id-ID"
    )}`;
  }

  calculateTotal();
}

function calculateTotal() {
  const foodQty = parseInt(document.getElementById("foodQty").value);
  const drinkQty = parseInt(document.getElementById("drinkQty").value);
  const foodPrice = parseFloat(document.getElementById("foodDropdown").value);
  const drinkPrice = parseFloat(document.getElementById("drinkDropdown").value);
  const totalPrice = foodQty * foodPrice + drinkQty * drinkPrice;
  document.getElementById(
    "totalPrice"
  ).textContent = `Rp ${totalPrice.toLocaleString("id-ID")}`;
}

function calculateChange() {
  const amountPaid = parseFloat(document.getElementById("amountPaid").value);
  const totalPrice = parseFloat(
    document.getElementById("totalPrice").textContent.replace("Rp ", "")
  );
  const change = amountPaid - totalPrice;
  document.getElementById("change").value = change;
}

function printReceipt() {
  // Implement your logic to print the receipt
  alert("Cetak struk belum diimplementasikan.");
}

function toggleDrinkSelection() {
  var drinkDropdown = document.getElementById("drinkDropdown");
  var includeDrinkCheckbox = document.getElementById("includeDrink");

  if (includeDrinkCheckbox.checked) {
    drinkDropdown.disabled = false;
  } else {
    drinkDropdown.disabled = true;
    drinkDropdown.selectedIndex = 0;
    document.getElementById("drinkPrice").textContent = "Harga: Rp 0";
  }

  updatePrice("drink");
}
